#ifndef TVSERIES_H
#define TVSERIES_H
#include "abstractItem.h"
#include <string>

namespace Item{
class TvSeries : public AbstractItem
{
private:
    unsigned int seasons;

public:
    TvSeries(
        const unsigned int id,
        const std::string title,
        const unsigned int year,
        const std::string description,
        const std::string imagePath,
        const unsigned int seasons
        );

    const unsigned int getSeasons() const;
    TvSeries& setSeasons(const unsigned int seasons);
};
}
#endif // TVSERIES_H
