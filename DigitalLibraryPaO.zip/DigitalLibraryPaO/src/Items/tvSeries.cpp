#include "tvSeries.h"

namespace Item{
TvSeries::TvSeries(
    const unsigned int id,
    const std::string title,
    const unsigned int year,
    const std::string description,
    const std::string imagePath,
    const unsigned int seasons
    ): AbstractItem::AbstractItem(id, title, year, description, imagePath), seasons(seasons){}

const unsigned int TvSeries::getSeasons() const {
    return this->seasons;
}
TvSeries& TvSeries::setSeasons(const unsigned int seasons){
    this->seasons=seasons;
    return *this;
}
}
\
