#ifndef AUDIOVISUALPRODUCT_H
#define AUDIOVISUALPRODUCT_H
#include "abstractItem.h"
#include <string>
#include <vector>


namespace Item{
    class AudiovisualProduct : public AbstractItem
    {
    private:
        std::string director;
        std::vector<std::string*> genres;

    public:
        AudiovisualProduct(
            const unsigned int id,
            const std::string title,
            const unsigned int year,
            const std::string description,
            const std::string imagePath,
            const std::string director,
            const std::vector<std::string*>& genres
            );

        const std::string getDirector() const;
        AudiovisualProduct& setDirector(const std::string director);
        const std::vector<std::string*>& getGenres() const;
        AudiovisualProduct& setGenres(const std::vector<std::string*>& genres);
    };
}
#endif // AUDIOVISUALPRODUCT_H
