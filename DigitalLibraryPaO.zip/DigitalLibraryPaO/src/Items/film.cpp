#include "film.h"

namespace Item{
Film::Film(
    const unsigned int id,
    const std::string title,
    const unsigned int year,
    const std::string description,
    const std::string imagePath,
    const unsigned int duration
    ): AbstractItem::AbstractItem(id, title, year, description, imagePath), duration(duration){}

const unsigned int Film::getDuration() const {
    return this->duration;
}
Film& Film::setDuration(const unsigned int duration){
    this->duration=duration;
    return *this;
}
}
\
