#ifndef FILM_H
#define FILM_H
#include "abstractItem.h"
#include <string>

namespace Item{
class Film : public AbstractItem
{
private:
    unsigned int duration;

public:
    Film(
        const unsigned int id,
        const std::string title,
        const unsigned int year,
        const std::string description,
        const std::string imagePath,
        const unsigned int duration
        );

    const unsigned int getDuration() const;
    Film& setDuration(const unsigned int duration);
};
}
#endif // FILM_H
