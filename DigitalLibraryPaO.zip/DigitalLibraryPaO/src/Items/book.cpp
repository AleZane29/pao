#include "book.h"

namespace Item{
    Book::Book(
        const unsigned int id,
        const std::string title,
        const unsigned int year,
        const std::string description,
        const std::string imagePath,
        const std::string author,
        const std::string publHouse,
        const std::string isbn
    ): AbstractItem::AbstractItem(id, title, year, description, imagePath), author(author), publishingHouse(publHouse), isbn(isbn){}

    const std::string Book::getAuthor() const {
        return this->author;
    }

    const std::string Book::getPublHouse() const {
        return this->publishingHouse;
    }

    const std::string Book::getIsbn() const {
        return this->isbn;
    }

    Book& Book::setAuthor(const std::string author){
        this->author=author;
        return *this;
    }
    Book& Book::setPublHouse(const std::string publHouse){
        this->publishingHouse=publHouse;
        return *this;
    }
    Book& Book::setIsbn(const std::string isbn){
        this->isbn=isbn;
        return *this;
    }
}
\
