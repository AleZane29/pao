#include "audiovisualProduct.h"

namespace Item{
AudiovisualProduct::AudiovisualProduct(
    const unsigned int id,
    const std::string title,
    const unsigned int year,
    const std::string description,
    const std::string imagePath,
    const std::string director,
    const std::vector<std::string*>& genres
    ): AbstractItem::AbstractItem(id, title, year, description, imagePath), director(director), genres(genres){}

const std::string AudiovisualProduct::getDirector() const {
    return this->director;
}

const std::vector<std::string*>& AudiovisualProduct::getGenres() const {
    return this->genres;
}

AudiovisualProduct& AudiovisualProduct::setDirector(const std::string director){
    this->director=director;
    return *this;
}
AudiovisualProduct& AudiovisualProduct::setGenres(const std::vector<std::string*>& genres){
    this->genres=genres;
    return *this;
}
}
\
