#ifndef ABSTRACTITEM_H
#define ABSTRACTITEM_H
#include <string>

namespace Item{
class AbstractItem
{
private:
    const unsigned int id;
    std::string title;
    unsigned int year;
    std::string description;
    std::string imagePath;

protected:
    AbstractItem(const unsigned int id, const std::string& title, const unsigned int year, const std::string& desc, const std::string& path);

public:
    virtual ~AbstractItem();
    const unsigned int getId() const;
    AbstractItem& setYear(const unsigned int year);
    const unsigned int getYear() const;
    AbstractItem& setTitle(const std::string title);
    const std::string getTitle() const;
    AbstractItem& setDescription(const std::string desc);
    const std::string getDescritpion() const;
    AbstractItem& setImagePath(const std::string path);
    const std::string getImagePath() const;
};
}
#endif // ABSTRACTITEM_H
