#include "abstractItem.h"

namespace Item{
    AbstractItem::AbstractItem(const unsigned int id, const std::string& title, const unsigned int year, const std::string& desc, const std::string& path)
    : id(id), title(title), year(year), description(desc), imagePath(path) {}

    AbstractItem::~AbstractItem() {}

    const unsigned int AbstractItem::getId() const {
        return this->id;
    }

    const unsigned int AbstractItem::getYear() const {
        return this->year;
    }

    const std::string AbstractItem::getTitle() const {
        return this->title;
    }

    const std::string AbstractItem::getDescritpion() const {
        return this->description;
    }

    const std::string AbstractItem::getImagePath() const {
        return this->imagePath;
    }

    AbstractItem& AbstractItem::setYear(const unsigned int year){
        this->year=year;
        return *this;
    }

    AbstractItem& AbstractItem::setTitle(const std::string title){
        this->title=title;
        return *this;
    }

    AbstractItem& AbstractItem::setDescription(const std::string desc){
        this->description=desc;
        return *this;
    }

    AbstractItem& AbstractItem::setImagePath(const std::string path){
        this->imagePath=path;
        return *this;
    }
}
