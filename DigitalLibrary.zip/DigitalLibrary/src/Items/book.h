#ifndef BOOK_H
#define BOOK_H
#include "abstractItem.h"
#include <string>

namespace Item{
class Book : public AbstractItem
{
private:
    std::string author;
    std::string publishingHouse;
    std::string isbn;

public:
    Book(
        const unsigned int id,
        const std::string title,
        const unsigned int year,
        const std::string description,
        const std::string imagePath,
        const std::string author,
        const std::string publHouse,
        const std::string isbn
        );

    const std::string getAuthor() const;
    Book& setAuthor(const std::string author);
    const std::string getPublHouse() const;
    Book& setPublHouse(const std::string publHouse);
    const std::string getIsbn() const;
    Book& setIsbn(const std::string isbn);
};
}
#endif // BOOK_H
